# Data Analysis Package
Librería para el análisis numérico y gráfico de los datos obtenidos de los equipos de ozonización (.mat), espectrofotómetro UV/Vis (.asc) y biorreacciones (datos en variables), en el Laboratorio de Ingeniería Química y Ambiental.
