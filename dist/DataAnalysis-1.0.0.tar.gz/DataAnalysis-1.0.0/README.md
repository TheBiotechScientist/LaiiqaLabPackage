# Data Analysis Package
Paquete para el análisis y graficado de los datos obtenidos de las cinéticas de ozonización (.mat) y los obtenidos del espectro UV/Vis (.asc).
